#!/usr/bin/env python
import prompt
from random import randint


def main():
    i = 0
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}!')
    print('Answer "yes" if the number is even, otherwise answer "no".')
    i = 0
    while i < 3:
        x = randint(1, 100)
        print(f'Question: {x}')
        answer = prompt.string('Your answer: ')
        if x % 2 == 0:
            if answer == 'yes':
                print('Correct')
            elif answer == 'no':
                print("'no' is wrong answer ;(. Correct answer was 'yes'."
                      f"Let's try again, {name}")
                break
        if x % 2 != 0:
            if answer == 'no':
                print('Correct')
            elif answer == 'yes':
                print("'yes' is wrong answer ;(. Correct answer was 'no'."
                      f"Let's try again, {name}")
                break
        i += 1
    if i == 3:
        print(f'Congratulations, {name}')


if __name__ == '__main__':
    main()
