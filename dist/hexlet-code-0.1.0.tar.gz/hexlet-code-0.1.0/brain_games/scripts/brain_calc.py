#!/usr/bin/env python
from brain_games.games import calc


def main():
    calc.calculate()


if __name__ == '__main__':
    main()
