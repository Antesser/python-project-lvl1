#!/usr/bin/env python
from brain_games.games import prime


def main():
    prime.main()


if __name__ == '__main__':
    main()
