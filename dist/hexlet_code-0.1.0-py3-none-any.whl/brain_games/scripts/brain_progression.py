#!/usr/bin/env python
from brain_games.games import progression


def main():
    progression.missing_number()


if __name__ == '__main__':
    main()
